from django.apps import AppConfig


class TemplatesConfig(AppConfig):
    name = 'templates'
