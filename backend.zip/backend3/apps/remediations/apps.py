from django.apps import AppConfig


class RemediationsConfig(AppConfig):
    name = 'remediations'
