from django.apps import AppConfig


class RenewalsConfig(AppConfig):
    name = 'renewals'
